# ⭐ 3. TASK 3 README — Gemini API Chatbot (IMPORTANT ONE)

# 🤖 Task 3: AI Chatbot using Gemini API

## 📌 Description

This is an advanced chatbot built using Google's Gemini API. It takes user input and returns AI-generated responses.

## 🧠 Concepts Used

- API integration
- Python requests / SDK
- Input/output handling
- Loops and condition checking

## ✨ Features

- Real-time AI responses using Gemini API
- Continuous chat until user exits
- Handles multiple types of queries
- More intelligent than rule-based chatbots

## 🔑 Requirements

- Google Gemini API key
- Internet connection

## 🚀 How to Run

```bash
python chatbot.py
```
