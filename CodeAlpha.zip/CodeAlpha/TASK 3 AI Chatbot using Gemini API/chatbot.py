from google import genai
from google.genai import errors

client = genai.Client(api_key="AIzaSyBMQRweojVck-GA79yv2JslWj5TAdmC860")

print("Chatbot is Ready. Type 'exit' to stop.\n")

while True:
    user_input = input("You: ")

    if user_input.lower() == "exit":
        print("Chatbot: Goodbye!!!")
        break

    try:
        response = client.models.generate_content(
            model="gemini-2.0-flash-lite",
            contents=user_input
        )
        print("Chatbot:", response.text)

    except errors.ClientError as e:
        if "429" in str(e):
            print("Chatbot: Sorry, quota exceeded. Please wait or check your billing.")
        else:
            print(f"Chatbot: API error — {e}")
    except Exception as e:
        print(f"Chatbot: Unexpected error — {e}")

    