# ⭐ 2. TASK 2 README — Stock Portfolio Tracker

# 📈 Task 2: Stock Portfolio Tracker

## 📌 Description

A simple stock portfolio tracker that calculates total investment based on user input and predefined stock prices.

## 🧠 Concepts Used

- Dictionaries
- User input/output
- Arithmetic operations
- File handling (optional)

## 💰 Features

- Predefined stock prices using dictionary
- User enters stock name and quantity
- Calculates total investment value
- Option to save result in a file (TXT/CSV)
