stock_prices = {
    "AAPL": 180,
    "TSLA": 250,
    "GOOG": 150,
    "AMZN": 130
}
total_investment = 0
print("Enter stocks (type 'done' to finish):")
while True:
    stock = input("Stock name: ").upper()
    if stock == "DONE":
        break
    if stock not in stock_prices:
        print("Stock not found in price list!")
        continue
    qty = int(input("Quantity: "))
    total_investment += stock_prices[stock] * qty
print("\nTotal Investment Value =", total_investment)

with open("portfolio.txt", "w") as f:
    f.write(f"Total Investment Value: {total_investment}")
print("Saved to portfolio.txt")