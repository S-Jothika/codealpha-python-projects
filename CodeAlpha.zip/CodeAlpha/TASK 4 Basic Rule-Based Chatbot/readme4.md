# ⭐ 4. TASK 4 README — Basic Rule-Based Chatbot

# 💬 Task 4: Basic Rule-Based Chatbot

## 📌 Description

A simple chatbot that responds to predefined user inputs using if-elif conditions.

## 🧠 Concepts Used

- if-elif statements
- functions
- loops
- input/output handling

## 💡 Features

- Responds to basic messages like:
  - "hello"
  - "how are you"
  - "bye"
- Continuous conversation loop
- Easy to extend with more responses

## 🚀 How to Run

```bash
python chatbot.py
```
