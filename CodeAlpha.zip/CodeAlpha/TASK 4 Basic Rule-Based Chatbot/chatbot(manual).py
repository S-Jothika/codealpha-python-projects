
def chatbot():
    print("Chatbot is ready! Type 'exit' to stop.\n")
    while True:
        user = input("You: ").lower()
        if user == "exit":
            print("Bot: Goodbye! Take care 😊")
            break
        elif user in ["hello", "hi", "hey", "hii", "good morning", "good evening"]:
            print("Bot: Hi there! How can I help you?")
        elif user in ["how are you", "how r u", "how are you doing", "how's it going"]:
            print("Bot: I'm fine, thanks! What about you?")
        elif user in ["what is your name", "who are you"]:
            print("Bot: I'm a simple rule-based chatbot 🤖")
        elif user in ["help", "what can you do"]:
            print("Bot: I can respond to greetings, simple questions, and chat with you!")
        elif user in ["thanks", "thank you", "thx"]:
            print("Bot: You're welcome!")
        elif user in ["bye", "goodbye", "see you"]:
             print("BYE!!!")
        else:
            print("Bot: Sorry, I didn't understand that. Try something else 😊")
chatbot()