# 🎯 Task 1: Hangman Game

## 📌 Description

This is a simple text-based Hangman game where the player guesses a hidden word one letter at a time. The player has a limited number of incorrect attempts.

## 🧠 Concepts Used

- Python lists
- Strings
- random module
- while loop
- if-else conditions

## 🎮 Features

- Random word selected from a predefined list
- Maximum 6 incorrect guesses allowed
- Displays progress after each guess
- Console-based gameplay

## 🧾 How to Run

```bash
python hangman.py
```
