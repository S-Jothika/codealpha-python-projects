import random
stages = ['''
  +---+
  |   |
  O   |
 /|\\ |
 / \\ |
      |
=========
''', '''
  +---+
  |   |
  O   |
 /|\\ |
 /    |
      |
=========
''', '''
  +---+
  |   |
  O   |
 /|\\ |
      |
      |
=========
''', '''
  +---+
  |   |
  O   |
 /|   |
      |
      |
=========
''', '''
  +---+
  |   |
  O   |
  |   |
      |
      |
=========
''', '''
  +---+
  |   |
  O   |
      |
      |
      |
=========
''', '''
  +---+
  |   |
      |
      |
      |
      |
=========
''']
chosen_word = random.choice(["apple", "mango", "lychee","lemon","kiwi","dog","sweets"])
display = []
lives = 6
for i in range(len(chosen_word)):
    display += '_'
print(display)
game_over = False
while not game_over:
    guessed_letter = input("Guess a letter: ").lower()
    for position in range(len(chosen_word)):
        letter = chosen_word[position]
        if letter == guessed_letter:
            display[position] = guessed_letter
    if guessed_letter not in chosen_word:
        lives -= 1
        if lives == 0:
            game_over = True
            print("Sorry, You Lose!!!")
    print(display)
    print(stages[lives])
    if '_' not in display:
        game_over = True
        print("Hurray, You Win!!!")