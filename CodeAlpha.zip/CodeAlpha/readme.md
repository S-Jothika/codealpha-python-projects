# 🚀 CodeAlpha Internship Projects

## 👩‍💻 About This Repository

This repository contains the projects completed as part of the **CodeAlpha Internship Program**.  
It includes 4 beginner-level Python projects focused on building programming fundamentals, logic building, and problem-solving skills.

---

## 📂 Projects Included

### 1️⃣ Task 1: Hangman Game

A text-based word guessing game where the player tries to guess the hidden word one letter at a time. The player has limited incorrect attempts.

### 2️⃣ Task 2: Stock Portfolio Tracker

A simple program that calculates total investment based on user input and predefined stock prices stored in a dictionary.

### 3️⃣ Task 3: AI Chatbot using Gemini API

An intelligent chatbot built using Google Gemini API that responds to user queries in real time using AI-generated responses.

### 4️⃣ Task 4: Basic Rule-Based Chatbot

A simple chatbot that responds to predefined inputs like "hello", "how are you", and "bye" using conditional statements.

---

## 🧠 Skills Learned

- Python basics (loops, conditions, functions)
- Dictionaries and string handling
- File handling (basic level)
- API integration (Gemini)
- Problem-solving and logic building

---

## 🙌 Acknowledgement

Special thanks to **CodeAlpha** for providing this internship opportunity and helping me improve my programming skills.
